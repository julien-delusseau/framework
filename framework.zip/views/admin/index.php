<div class="container-fluid py-4">
    <h1 class="text-4xl">Page d'accueil</h1>

    <?php require_once ROOT . '/views/admin/includes/new_posts.php' ?>
    <?php require_once ROOT . '/views/admin/includes/new_users.php' ?>

</div>
