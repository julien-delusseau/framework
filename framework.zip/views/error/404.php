<div class="centered">
    <h3>404</h3>
    <p>
        Oups. Cette page n'existe pas ...
    </p>
</div>