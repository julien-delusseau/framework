<form method="post" enctype="multipart/form-data">
    <div>
        <label for="image">Votre avatar</label>
        <input class="form-control" id="image" type="file" name="image" />
    </div>
    <br />
    <!-- Submit Button-->
    <button class="btn btn-color btn-rounded" id="submitButton" type="submit">
        Envoyer
    </button>
</form>